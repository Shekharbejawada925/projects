import React from 'react';
import { Cpu, Database, Globe, Server } from 'lucide-react';
import { Department } from '../types';

export const departments: Department[] = [
  {
    id: 'cse',
    name: 'Computer Science',
    projectCount: 45,
    icon: <Cpu className="w-8 h-8 text-blue-600" />,
  },
  {
    id: 'it',
    name: 'Information Technology',
    projectCount: 38,
    icon: <Database className="w-8 h-8 text-blue-600" />,
  },
  {
    id: 'ece',
    name: 'Electronics & Communication',
    projectCount: 42,
    icon: <Server className="w-8 h-8 text-blue-600" />,
  },
  {
    id: 'eee',
    name: 'Electrical & Electronics',
    projectCount: 35,
    icon: <Globe className="w-8 h-8 text-blue-600" />,
  },
];