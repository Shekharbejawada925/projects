// Update one project example to include resources
{
  // ... existing project properties ...
  resources: {
    sourceCode: {
      url: 'https://github.com/username/healthcare-monitoring/archive/main.zip',
      description: 'Complete source code including frontend, backend, and IoT device configuration files.'
    },
    documentation: [
      {
        url: 'https://example.com/docs/healthcare-monitoring-setup.pdf',
        type: 'pdf',
        size: '2.4 MB'
      },
      {
        url: 'https://example.com/docs/api-documentation.pdf',
        type: 'pdf',
        size: '1.8 MB'
      }
    ],
    presentation: [
      {
        url: 'https://example.com/presentations/project-overview.pptx',
        title: 'Project Overview Presentation',
        size: '5.2 MB'
      },
      {
        url: 'https://example.com/presentations/technical-architecture.pptx',
        title: 'Technical Architecture & Implementation',
        size: '3.8 MB'
      }
    ],
    additionalResources: [
      {
        title: 'Research Paper',
        url: 'https://example.com/papers/healthcare-monitoring-research.pdf',
        type: 'pdf',
        description: 'Published research paper detailing the system architecture and results'
      },
      {
        title: 'Video Demo',
        url: 'https://example.com/videos/system-demo.mp4',
        type: 'video',
        description: 'Complete system demonstration and usage tutorial'
      }
    ]
  }
}