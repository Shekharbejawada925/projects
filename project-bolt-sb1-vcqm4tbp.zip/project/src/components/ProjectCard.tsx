import React, { useState } from 'react';
import { Github, ExternalLink, Rocket, FileText } from 'lucide-react';
import { Project } from '../types';
import DeploymentModal from './DeploymentModal';
import ResourcesModal from './ResourcesModal';

interface ProjectCardProps {
  project: Project;
}

const ProjectCard = ({ project }: ProjectCardProps) => {
  const [showDeployment, setShowDeployment] = useState(false);
  const [showResources, setShowResources] = useState(false);

  return (
    <>
      <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
        <img 
          src={project.image} 
          alt={project.title} 
          className="w-full h-48 object-cover"
        />
        <div className="p-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xl font-bold text-gray-800">{project.title}</h3>
            <span className="text-sm text-gray-500">{project.year}</span>
          </div>
          <p className="text-gray-600 mb-4">{project.description}</p>
          <div className="flex flex-wrap gap-2 mb-4">
            {project.technologies.map((tech, index) => (
              <span 
                key={index}
                className="px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-sm"
              >
                {tech}
              </span>
            ))}
          </div>
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center space-x-2">
              {project.students.map((student, index) => (
                <img 
                  key={index}
                  src={student.avatar} 
                  alt={student.name}
                  className="w-8 h-8 rounded-full"
                  title={student.name}
                />
              ))}
            </div>
            <div className="flex space-x-3">
              <button
                onClick={() => setShowResources(true)}
                className="text-green-600 hover:text-green-800 flex items-center gap-1"
              >
                <FileText size={20} />
                <span>Resources</span>
              </button>
              <button
                onClick={() => setShowDeployment(true)}
                className="text-blue-600 hover:text-blue-800 flex items-center gap-1"
              >
                <Rocket size={20} />
                <span>Deploy</span>
              </button>
              {project.github && (
                <a href={project.github} target="_blank" rel="noopener noreferrer" 
                  className="text-gray-600 hover:text-blue-600">
                  <Github size={20} />
                </a>
              )}
              {project.demo && (
                <a href={project.demo} target="_blank" rel="noopener noreferrer"
                  className="text-gray-600 hover:text-blue-600">
                  <ExternalLink size={20} />
                </a>
              )}
            </div>
          </div>
        </div>
      </div>

      <DeploymentModal
        isOpen={showDeployment}
        onClose={() => setShowDeployment(false)}
        deployment={project.deployment}
      />
      
      <ResourcesModal
        isOpen={showResources}
        onClose={() => setShowResources(false)}
        resources={project.resources}
        projectTitle={project.title}
      />
    </>
  );
};

export default ProjectCard;