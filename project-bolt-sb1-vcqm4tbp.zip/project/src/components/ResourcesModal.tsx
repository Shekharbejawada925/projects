import React from 'react';
import { X, FileText, FileCode, Presentation, Download, ExternalLink } from 'lucide-react';
import { ProjectResources } from '../types';

interface ResourcesModalProps {
  isOpen: boolean;
  onClose: () => void;
  resources: ProjectResources;
  projectTitle: string;
}

const ResourcesModal = ({ isOpen, onClose, resources, projectTitle }: ResourcesModalProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-800">Project Resources</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X size={24} />
            </button>
          </div>

          {/* Source Code Section */}
          {resources.sourceCode && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center">
                <FileCode className="mr-2" /> Source Code
              </h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700 mb-3">{resources.sourceCode.description}</p>
                <a 
                  href={resources.sourceCode.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-blue-600 hover:text-blue-800"
                >
                  <Download className="mr-2" size={18} />
                  Download Source Code
                </a>
              </div>
            </div>
          )}

          {/* Documentation Section */}
          {resources.documentation && resources.documentation.length > 0 && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center">
                <FileText className="mr-2" /> Documentation
              </h3>
              <div className="space-y-3">
                {resources.documentation.map((doc, index) => (
                  <div key={index} className="bg-gray-50 p-4 rounded-lg flex items-center justify-between">
                    <div>
                      <p className="font-medium">{projectTitle} Documentation</p>
                      <p className="text-sm text-gray-500">Format: {doc.type.toUpperCase()} • Size: {doc.size}</p>
                    </div>
                    <a 
                      href={doc.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-blue-600 hover:text-blue-800"
                    >
                      <Download size={18} />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Presentation Section */}
          {resources.presentation && resources.presentation.length > 0 && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center">
                <Presentation className="mr-2" /> Presentations
              </h3>
              <div className="space-y-3">
                {resources.presentation.map((ppt, index) => (
                  <div key={index} className="bg-gray-50 p-4 rounded-lg flex items-center justify-between">
                    <div>
                      <p className="font-medium">{ppt.title}</p>
                      <p className="text-sm text-gray-500">Size: {ppt.size}</p>
                    </div>
                    <a 
                      href={ppt.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-blue-600 hover:text-blue-800"
                    >
                      <Download size={18} />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Additional Resources */}
          {resources.additionalResources && resources.additionalResources.length > 0 && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3">Additional Resources</h3>
              <div className="space-y-3">
                {resources.additionalResources.map((resource, index) => (
                  <div key={index} className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium">{resource.title}</p>
                        <p className="text-sm text-gray-600">{resource.description}</p>
                      </div>
                      <a 
                        href={resource.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center text-blue-600 hover:text-blue-800"
                      >
                        <ExternalLink size={18} />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResourcesModal;