import React from 'react';
import { X, Terminal, GitBranch, Package, Server } from 'lucide-react';
import { DeploymentDetails } from '../types';

interface DeploymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  deployment: DeploymentDetails;
}

const DeploymentModal = ({ isOpen, onClose, deployment }: DeploymentModalProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-800">Deployment Guide</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X size={24} />
            </button>
          </div>

          {/* Prerequisites */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3 flex items-center">
              <Package className="mr-2" /> Prerequisites
            </h3>
            <ul className="list-disc pl-6 space-y-2">
              {deployment.prerequisites.map((req, index) => (
                <li key={index} className="text-gray-700">{req}</li>
              ))}
            </ul>
          </div>

          {/* Setup Steps */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3 flex items-center">
              <Terminal className="mr-2" /> Setup Steps
            </h3>
            <div className="space-y-4">
              {deployment.steps.map((step, index) => (
                <div key={index} className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Step {index + 1}: {step.title}</h4>
                  <p className="text-gray-700 mb-2">{step.description}</p>
                  {step.code && (
                    <pre className="bg-gray-900 text-white p-3 rounded-md overflow-x-auto">
                      <code>{step.code}</code>
                    </pre>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Environment Setup */}
          {deployment.environmentSetup && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center">
                <Server className="mr-2" /> Environment Setup
              </h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700 mb-3">{deployment.environmentSetup.description}</p>
                <pre className="bg-gray-900 text-white p-3 rounded-md overflow-x-auto">
                  <code>{deployment.environmentSetup.variables}</code>
                </pre>
              </div>
            </div>
          )}

          {/* Additional Notes */}
          {deployment.notes && (
            <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
              <h3 className="text-lg font-semibold mb-2">Important Notes</h3>
              <ul className="list-disc pl-6 space-y-2">
                {deployment.notes.map((note, index) => (
                  <li key={index} className="text-gray-700">{note}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DeploymentModal;