import React from 'react';

const Navbar = () => {
  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <img 
              src="https://vignanbharathi.edu.in/wp-content/uploads/2023/05/vbit-logo.png" 
              alt="VBIT Logo" 
              className="h-12"
            />
            <div className="flex flex-col">
              <span className="font-bold text-xl text-gray-800">VBIT Projects</span>
              <span className="text-sm text-gray-600">Vignana Bharathi Institute of Technology</span>
            </div>
          </div>
          <div className="hidden md:flex space-x-6">
            <NavLink href="#projects">Projects</NavLink>
            <NavLink href="#departments">Departments</NavLink>
            <NavLink href="#guidelines">Guidelines</NavLink>
            <NavLink href="#contact">Contact</NavLink>
          </div>
        </div>
      </div>
    </nav>
  );
};

const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => (
  <a 
    href={href} 
    className="text-gray-600 hover:text-blue-600 transition-colors"
  >
    {children}
  </a>
);

export default Navbar;