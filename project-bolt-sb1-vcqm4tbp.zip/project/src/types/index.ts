// ... existing interfaces ...

export interface ProjectResources {
  sourceCode?: {
    url: string;
    description: string;
  };
  documentation?: {
    url: string;
    type: 'pdf' | 'doc' | 'html';
    size: string;
  }[];
  presentation?: {
    url: string;
    title: string;
    size: string;
  }[];
  additionalResources?: {
    title: string;
    url: string;
    type: string;
    description: string;
  }[];
}

export interface Project {
  // ... existing properties ...
  resources: ProjectResources;
}